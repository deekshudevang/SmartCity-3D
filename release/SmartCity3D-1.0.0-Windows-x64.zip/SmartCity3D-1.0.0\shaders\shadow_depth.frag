#version 330 core

void main() {
    // gl_FragDepth is automatically written by the graphics hardware
}
